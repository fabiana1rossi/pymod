# Copyright 2020 by Giacomo Janson. All rights reserved.
# This code is part of the PyMod package and governed by its license. Please
# see the LICENSE file that should have been included as part of this package
# or the main __init__.py file in the pymod3 folder.

import os
import subprocess
import sys
import shutil
import re
import time
import glob

from pymod_lib import pymod_vars
from pymod_lib import pymod_tool as pm_tool
from pymod_lib.pymod_os_specific import pymod_which, get_exe_file_name
from pymod_lib.pymod_gui.shared_gui_components_qt import (PyMod_protocol_window_qt,
                                                          PyMod_entryfield_qt,
                                                          PyMod_radioselect_qt,
                                                          PyMod_combobox_qt,
                                                          PyMod_hbox_option_qt,
                                                          askyesno_qt,
                                                          askopenfile_qt)

from ._evolutionary_analysis_base import Evolutionary_analysis_protocol
from ._tree_visualization import bubble_ly, ColumnMutation

from Bio import Phylo
from Bio import AlignIO, SeqIO
from Bio.Phylo import TreeConstruction
from Bio.Phylo.Consensus import *
from Bio.Phylo.TreeConstruction import DistanceCalculator, DistanceTreeConstructor
from Bio.Phylo.Applications import RaxmlCommandline

from ete3 import Tree, PhyloTree, AttrFace, TreeFace, TreeStyle, TextFace, NodeStyle, faces

from PyQt5 import QtWidgets, QtCore, QtGui
from PyQt5.QtCore import QObject, pyqtSignal, QThread, pyqtSlot
from PyQt5.QtWidgets import QInputDialog, QLineEdit,QWidget, QProgressBar, QPushButton, QApplication, QVBoxLayout, QDesktopWidget
from PyQt5.QtGui import QDialog, QFormLayout, QLabel, QListView, QStandardItemModel, QDialogButtonBox, QStandardItem

tree_building_alg_dict = {"Neighbor Joining": "NJ", "UPGMA": "UPGMA", "Parsimony" : "Parsimony"}

calculator_matrix_dict = {"Identity" : True, "Blosum62" : False}

visualization_dict = {"Alignment" : "aln", "Basic" : "bp", "Evolutionary events" : "evo",  "Mutation Events": "mut_all","Single Mutation Event": "mut_single", "Bootstrap Analysis" : "bootstrap"}

random_trees_dict = {"100":100, "500":500, "1000": 1000}

class Tree_building(Evolutionary_analysis_protocol):

    def launch_from_gui(self):
        """
        It will check if a software to build a tree is available on the user's machine.
        """
        ####################
        # Biopython module #
        ####################

        self.tree_building_software = None
        can_build_tree = False
        if self.check_tree_constructor_module():
            self.tree_building_software = "biopython"
            can_build_tree = True

        if can_build_tree:
            self.build_tree_building_window()
        else:
            title = "Tree building Error"
            message = "In order to build a tree out of an alignment you need to install Biopython."
            self.pymod.main_window.show_error_message(title, message)

    def check_tree_constructor_module(self):
        try:
            import Bio.Phylo.TreeConstruction
            return True
        except ImportError:
            return False

    def build_tree_building_window(self):
        """
        Builds a window with options to build a tree out of an alignment.
        """

        self.tree_building_window = Tree_building_window_qt(self.pymod.main_window,
            protocol=self,
            title="Options for Tree Building",
            upper_frame_title="Here you can modify options for Tree Building",
            submit_command=self.run_tree_building_software)
        self.tree_building_window.show()


    def run_tree_building_software(self):
        # Saves a temporary input alignment file.
        alignment_file_name = "alignment_tmp"
        self.alignment_file_path = os.path.join(self.pymod.alignments_dirpath, alignment_file_name + '.fasta')
        self.pymod.save_alignment_fasta_file(alignment_file_name, self.input_cluster_element.get_children())
        self.pymod.tree_aln_id = self.input_cluster_element.cluster_id

        # Get the parameters from the GUI.
        clustering_algorithm = self.get_clustering_algorithm()

        self.new_aln_file_path = os.path.join(self.pymod.alignments_dirpath, alignment_file_name + '.phylip')
        self.edit_FASTA_file(self.alignment_file_path, self.new_aln_file_path)
        aln = AlignIO.read(self.new_aln_file_path, 'fasta')

        if clustering_algorithm == "Parsimony":

            scorer = TreeConstruction.ParsimonyScorer()
            searcher = TreeConstruction.NNITreeSearcher(scorer)
            constructor = TreeConstruction.ParsimonyTreeConstructor(searcher)
            pars_tree = constructor.build_tree(aln)

            new_tree_file_name = "%s_%s_align_tree.phy" % (self.pymod.alignments_files_names, self.input_cluster_element.unique_index)
            self.new_tree_file_path = os.path.join(self.pymod.alignments_dirpath, new_tree_file_name)

            self.new_tree_file_name_output_file = "%s_%s_tree_output_PARSIMONY.nwk" % (self.pymod.alignments_files_names, self.input_cluster_element.unique_index)
            self.new_tree_file_path_cleaned = os.path.join(self.pymod.alignments_dirpath, self.new_tree_file_name_output_file)

            Phylo.write(pars_tree, self.new_tree_file_path, "newick")
            self.remove_Inner_label(self.new_tree_file_path,self.new_tree_file_path_cleaned)

            # Bootstrap analysis with RAxML requirement.
            self.to_be_unrooted = True

        elif clustering_algorithm == "NJ":

            calculator_type = self.set_calculator_value()[1]
            calculator = self.set_calculator_value()[0]
            constructor = DistanceTreeConstructor(calculator, 'nj')
            nj_tree = constructor.build_tree(aln)

            new_tree_file_name = "%s_%s_align_tree.phy" % (self.pymod.alignments_files_names, self.input_cluster_element.unique_index)
            self.new_tree_file_path = os.path.join(self.pymod.alignments_dirpath, new_tree_file_name)

            self.new_tree_file_name_output_file = "%s_%s_tree_output_NJ.nwk" % (self.pymod.alignments_files_names, self.input_cluster_element.unique_index)
            self.new_tree_file_path_cleaned = os.path.join(self.pymod.alignments_dirpath, self.new_tree_file_name_output_file)

            Phylo.write(nj_tree, self.new_tree_file_path, "newick")
            self.remove_Inner_label(self.new_tree_file_path,self.new_tree_file_path_cleaned)

            # Bootstrap analysis with RAxML requirement.
            self.to_be_unrooted = False

        elif clustering_algorithm == "UPGMA":

            calculator_type = self.set_calculator_value()[1]
            calculator = self.set_calculator_value()[0]
            constructor = DistanceTreeConstructor(calculator, 'upgma')
            upgma_tree = constructor.build_tree(aln)

            new_tree_file_name = "%s_%s_align_tree.phy" % (self.pymod.alignments_files_names, self.input_cluster_element.unique_index)
            self.new_tree_file_path = os.path.join(self.pymod.alignments_dirpath, new_tree_file_name)

            self.new_tree_file_name_output_file = "%s_%s_tree_output_UPGMA.nwk" % (self.pymod.alignments_files_names, self.input_cluster_element.unique_index)
            self.new_tree_file_path_cleaned = os.path.join(self.pymod.alignments_dirpath, self.new_tree_file_name_output_file)

            Phylo.write(upgma_tree, self.new_tree_file_path, "newick")
            self.remove_Inner_label(self.new_tree_file_path, self.new_tree_file_path_cleaned)

            # Bootstrap analysis with RAxML requirement.
            self.to_be_unrooted = True


        self.show_plot_window(self.new_tree_file_path_cleaned)

        #Remove temporary files.
        #os.remove(self.alignment_file_path)
        self.tree_building_window.destroy()


        #######################################################################
        # Tree dictionary to be appended to the alignment clusters list
        try:
            tree = {"algorithm": [clustering_algorithm, calculator_type] ,
                    "filepath": self.new_tree_file_path_cleaned}

        # Parsimony has not calculator option.
        except UnboundLocalError:
            tree = {"algorithm": clustering_algorithm ,
                    "filepath": self.new_tree_file_path_cleaned}


        # Set "trees_list" attribute for old saved Pymod sessions.
        if not hasattr(self.input_cluster_element, "trees_list"):
            setattr(self.input_cluster_element, 'trees_list',[])

        self.input_cluster_element.trees_list.append(tree)
        ######################################################################

        self.pymod.main_window.gridder(clear_selection=True, update_clusters=True,
                                   update_menus=True, update_elements=True)


    def edit_FASTA_file(self, input_file, output_file):
        '''
        Change the record id in a FASTA file using BioPython.
        '''
        with open(input_file) as original, open(output_file, 'w') as corrected:
            records = SeqIO.parse(input_file, 'fasta')
            # Duplicate names found errors.
            bad_chars = ['_', 'c', 'h', 'a', 'i', 'n'] #"_chain_"
            for record in records:
                if len(record.id) > 10:
                    if "chain" in record.id:
                        for i in bad_chars :
                            record.id = record.id.replace(i, '')
                    record.id = record.id[0:10]
                    record.description = record.id[0:10]
                SeqIO.write(record, corrected, 'fasta')


    def remove_Inner_label(self,input_file,output_file):
        '''
        Remove "Inner" node label from Phylo.write output.
        '''
        input = open(input_file, "r")
        output = open(output_file, "w")
        output.write(input.read().replace("Inner",""))
        input.close()
        output.close()


    def show_plot_window(self,tree_file_path):
        visualization = self.get_visualization_mode()

        if visualization == "bp":
            self.pymod.show_tree(tree_file_path)

        if visualization == "aln":
            ts = TreeStyle()
            tree = PhyloTree(tree_file_path, format = 1)
            with open(self.alignment_file_path,'r') as f:
                aln = f.read()
            tree.link_to_alignment(aln)

            tree.show(tree_style=ts)

        if visualization == "mut_single":
            tree = PhyloTree(tree_file_path, format = 1)
            with open(self.new_aln_file_path,'r') as f:
                aln = f.read()
            tree_params = ColumnMutation()
            t, ts = tree_params.get_mutation_event(tree, aln, True)

            t.show(tree_style=ts)

        if visualization == "mut_all":

            tree = PhyloTree(tree_file_path, format = 1)
            with open(self.new_aln_file_path,'r') as f:
                aln = f.read()

            # aln = """
            # >Dme_001
            # MAEIPDETIQQFMALT---HNIAVQYLSEFGDLNEAL--YYASQTDDIKDRREEAH
            # >Dme_002
            # MAEIPDATIQQFMALTNVSHNIAVQY--EFGDLNEALNSYYAYQTDDQKDRREEAH
            # >Cfa_001
            # MAEIPDATIQ---ALTNVSHNIAVQYLSEFGDLNEALNSYYASQTDDQPDRREEAH
            # >Mms_001
            # MAEAPDETIQQFMALTNVSHNIAVQYLSEFGDLNEAL--------------REEAH
            # >Hsa_001
            # MAEIPDETIQQFMALT---HNIAVQYLSEFGDLNEALNSYYASQTDDIKDRREEAH
            # >Ptr_002
            # MAEIPDATIQ-FMALTNVSHNIAVQY--EFGDLNEALNSY--YQTDDQKDRREEAH
            # >Mmu_002
            # MAEIPDATIQ---ALTNVSHNIAVQYLSEFGDLNEALNSYYASQTDDQPDRREEAH
            # >Hsa_002
            # MAEAPDETIQQFM-LTNVSHNIAVQYLSEFGDLNEAL--------------REEAH
            # >Ptr_001
            # MAEIPDATIQ-FMALTNVSHNIAVQY--EFGDLNEALNSY--YQTDDQKDRREEAH
            # >Mmu_001
            # MAEIPDTTIQ---ALTNVSHNIAVQYLSEFGDLNEALNSYYASQTDDQPDRREEAH
            # """
            # gene_tree_nw = '((Dme_001,Dme_002),(((Cfa_001,Mms_001),((Hsa_001,Ptr_001),Mmu_001)),(Ptr_002,(Hsa_002,Mmu_002))));'
            # tree = PhyloTree(gene_tree_nw)
            tree_params = ColumnMutation()
            t, ts = tree_params.get_mutation_event(tree, aln, False)

            t.show(tree_style=ts)

        if visualization == "evo":
            tree = PhyloTree(tree_file_path, format = 1)
            try:
                ts = TreeStyle()
                # Get evolutionary events for each internal node (Duplication or Speciation).
                events = tree.get_descendant_evol_events()
                i = 0
                for n in tree.traverse():
                    if not n.is_leaf():
                        ev = events[i]
                        if ev.etype == "S":
                            # Add node face.
                            n.add_face(TextFace("S",fgcolor = "blue", penwidth = 8), column = i, position = "branch-top")
                        elif ev.etype == "D":
                            # Add node face.
                            n.add_face(TextFace("D", fgcolor = "red", penwidth = 8), column = i, position = "branch-top")
                        i += 1
                ts.mode = "c"
                ts.show_leaf_name = True

                tree.show(tree_style=ts)

            except TypeError:
                title = "Error"
                message = "The Tree is not rooted."
                self.pymod.main_window.show_error_message(title, message)
                pass


        if visualization == "bootstrap":
            # Get User input number of random trees.
            self.number_random_trees = self.get_random_trees()

            title = "Bootstrap Analysis"
            message = ("The Bootstrap Analysis will produce %s random trees and the process may take some time depending on the size of your multiple alignment. Do you want to proceed?"% self.number_random_trees)
            answer = askyesno_qt(title, message)
            if answer:
                if not hasattr(self.pymod, "raxml"):
                    title = "RAxML Error"
                    message = "You cannot run RAxML on sessions previous its installation."
                    self.pymod.main_window.show_error_message(title, message)
                    pass

                tree = PhyloTree(tree_file_path, format = 1)
                # Convert FASTA to PHYLIP format needed by RAxML
                self.new_aln_file_path_phy = os.path.join(self.pymod.alignments_dirpath, "alignment_tmp_boot.phylip")
                records = SeqIO.parse(self.new_aln_file_path, "fasta")
                SeqIO.write(records, self.new_aln_file_path_phy, "phylip")

                # UPGMA and Parsimony generate rooted trees which are not processable by RAxML (bootstrap analysis).
                if self.to_be_unrooted:
                    tree.unroot() # converts a split into multifurcation
                    # Save the unrooted tree in a new file.
                    tree_file_path = os.path.join(self.pymod.alignments_dirpath, "%s_%s_unrooted_tree.nwk" % (self.pymod.alignments_files_names, self.input_cluster_element.unique_index))
                    tree.write(format = 1, outfile = tree_file_path)
                else:
                    pass


                # ProgressBar.
                self.popup = PopUpProgressB(pymod = self,
                                            main_window = self.pymod.main_window,
                                            pymod_tool = self.pymod.raxml,
                                            current_pymod_dirpath = self.pymod.current_pymod_dirpath,
                                            external_tools_dirname = self.pymod.external_tools_dirname,
                                            alignments_files_names = self.pymod.alignments_files_names,
                                            input_cluster_element = self.input_cluster_element.unique_index,
                                            alignment_file_path = self.new_aln_file_path_phy,
                                            alignments_dirpath =self.pymod.alignments_dirpath,
                                            tree_file_path = tree_file_path,
                                            tree_id = self.new_tree_file_name_output_file,
                                            tree = tree,
                                            num_random_trees = self.number_random_trees)
                self.popup.start_progress()

            else:
                pass


    def get_visualization_mode(self):
        return visualization_dict[self.tree_building_window.visualization_rds.getvalue()]

    def get_clustering_algorithm(self):
        return tree_building_alg_dict[self.tree_building_window.algorithm_rds.getvalue()]

    def get_calculator(self):
        return calculator_matrix_dict[self.tree_building_window.calculator_rds.getvalue()]

    def get_random_trees(self):
        return random_trees_dict[self.tree_building_window.random_trees_rds.getvalue()]


    def set_calculator_value(self):
        if self.get_calculator():
            calculator = DistanceCalculator('identity')
            calculator_type = "Identity Matrix"
        else:
            calculator = DistanceCalculator('blosum62')
            calculator_type = "Blosum62 Matrix"
        return calculator, calculator_type



class PopUpProgressB(QWidget):
    def __init__(self,pymod, main_window, pymod_tool, current_pymod_dirpath, external_tools_dirname, alignments_files_names,
                    input_cluster_element, alignment_file_path, alignments_dirpath, tree_file_path, tree_id, tree, num_random_trees):

        super().__init__()
        self.pbar = QProgressBar(self)

        # Setting maximum value of progress bar based on the number of random trees.
        self.pbar.setMaximum(num_random_trees)

        self.layout = QVBoxLayout()
        self.layout.addWidget(self.pbar)
        self.setLayout(self.layout)
        self.setWindowTitle('Bootstrap Analysis')

        # Centering QtWidgets ProgressBar.
        qtRectangle = self.frameGeometry()
        centerPoint = QDesktopWidget().availableGeometry().center()
        qtRectangle.moveCenter(centerPoint)
        self.move(qtRectangle.topLeft())
        self.resize(350, 100)

        # Adding Stop Button
        self.button_stop = QPushButton('Stop', self)
        self.button_stop.clicked.connect(self.kill_thread)
        self.button_stop.move(240, 64)

        self.pymod = pymod
        self.pymod.main_window = main_window
        self.pymod.raxml = pymod_tool
        self.pymod.current_pymod_dirpath = current_pymod_dirpath
        self.pymod.external_tools_dirname = external_tools_dirname
        self.pymod.alignments_files_names = alignments_files_names
        self.pymod.input_cluster_element.unique_index = input_cluster_element
        self.new_aln_file_path_phy = alignment_file_path
        self.pymod.alignments_dirpath = alignments_dirpath
        self.tree_file_path = tree_file_path
        self.new_tree_file_name_output_file = tree_id
        self.tree = tree
        self.number_random_trees = num_random_trees


        self.thread = Worker(self.pymod, self.pymod.main_window, self.pymod.alignments_files_names, self.pymod.input_cluster_element.unique_index,
                                    self.pymod.alignments_dirpath, self.new_aln_file_path_phy, self.tree_file_path, self.new_tree_file_name_output_file, self.tree, self.number_random_trees)

        self.thread.intReady.connect(self.on_count_changed)
        self.thread.finished.connect(self.thread.quit)
        self.thread.showTree.connect(self.show_tree)
        self.thread.closeProgressBar.connect(self.show_message)

    def start_progress(self):
        self.show()
        self.thread.start()


    def kill_thread(self):
        '''
        Stop Thread and Subprocess via the 'STOP' button
        '''
        # Get RAxML child subprocess.
        self.raxml_subprocess = self.thread.get_subp()
        # Close ProgressBar.
        self.close()
        # Stop Thread.
        self.thread.terminate()
        # Kill child subprocess.
        self.raxml_subprocess.kill()
        # Remove incomplete files.
        random_trees_incomplete_file_path = os.path.join(self.pymod.alignments_dirpath, "RAxML_bootstrap.%s_BOOT%s" % (self.new_tree_file_name_output_file,self.number_random_trees))
        os.remove(random_trees_incomplete_file_path)
        RAxML_info_file_path = os.path.join(self.pymod.alignments_dirpath, "RAxML_info.%s_BOOT%s" % (self.new_tree_file_name_output_file,self.number_random_trees))
        os.remove(RAxML_info_file_path)

    def on_count_changed(self, value):
        # Update ProgressBar.
        self.pbar.setValue(value)

    def show_tree(self):
        # Close ProgressBar
        self.close()
        # Add bootstrap values/weights to internal nodes.
        i = 0
        self.bipartition_values = self.thread.get_bipartition_values()
        # print(self.bipartition_values)
        # print(self.tree)
        for n in self.tree.traverse():
            if not n.is_leaf() and not n.is_root():
                n.add_features(weight=int(self.bipartition_values[i]))
                # Show branch weight.
                support = faces.AttrFace("weight", fsize=9, ftype="Arial", fgcolor="darkred", formatter = "%0.3g")
                n.add_face(support, i, position="branch-bottom")
                i += 1

        ts = TreeStyle()
        ts.layout_fn = bubble_ly
        # Draw a tree
        ts.mode = "c"
        # add node names manually
        ts.show_leaf_name = False
        # Show branch data
        ts.show_branch_length = True
        ts.show_branch_support = False
        self.tree.show(tree_style=ts)

    def show_message(self):
        title = "Bootstrap Analysis"
        message = "Bootstrapping analysis with %s random trees has already been performed. You can visualize the final Tree via the 'Trees' menu" % self.number_random_trees
        self.pymod.main_window.show_error_message(title, message)
        # Close ProgressBar.
        self.close()

class Worker(QThread,QObject):
    finished = pyqtSignal()
    intReady = pyqtSignal(int)
    showTree = pyqtSignal()
    closeProgressBar = pyqtSignal()

    def __init__(self, pymod, main_window, alignments_files_names, input_cluster_element, alignments_dirpath, alignment_file_path, tree_file_path, tree_id, tree, num_random_trees):
        super().__init__()

        self.pymod = pymod
        self.pymod.main_window = main_window
        self.pymod.alignments_files_names = alignments_files_names
        self.pymod.input_cluster_element.unique_index = input_cluster_element
        self.pymod.alignments_dirpath = alignments_dirpath
        self.new_aln_file_path_phy = alignment_file_path
        self.tree_file_path = tree_file_path
        self.new_tree_file_name_output_file = tree_id
        self.tree = tree
        self.number_random_trees = num_random_trees

    @pyqtSlot()
    def run (self):
        if not hasattr(self.pymod, "raxml"):
            title = "RAxML Error"
            message = "You cannot run RAxML on sessions previous its installation."
            self.pymod.main_window.show_error_message(title, message)

        self.tool = self.pymod.raxml
        # RaXML executable file path.
        self.raxml_PTHREADS_AVX_exe_filepath = os.path.join(self.tool["exe_dir_path"].get_value(), get_exe_file_name("raxmlHPC_PTHREADS_AVX"))

        '''
        Execute RAxML

        '''
        # Check whether the Bootstrap file already exists.
        random_trees_file_path = os.path.join(self.pymod.alignments_dirpath, "RAxML_bootstrap.%s_BOOT%s" %(self.new_tree_file_name_output_file,self.number_random_trees))
        if os.path.isfile(random_trees_file_path):
            self.closeProgressBar.emit()
        else:
            # Generates random trees from alignment.
            self.raxml_cline_BOOT = RaxmlCommandline(self.raxml_PTHREADS_AVX_exe_filepath ,algorithm = "d",model= "PROTGAMMAJTT", sequences=self.new_aln_file_path_phy,
                                                        threads = 4, bootstrap_seed ="12463",parsimony_seed ="54439",working_dir=self.pymod.alignments_dirpath,
                                                        name = "%s_BOOT%s" %(self.new_tree_file_name_output_file,self.number_random_trees),
                                                        num_replicates=self.number_random_trees)

            self.execute_subprocess(str(self.raxml_cline_BOOT))

            # Create file path for random trees.
            random_trees_file_path = os.path.join(self.pymod.alignments_dirpath, "RAxML_bootstrap.%s_BOOT%s" %(self.new_tree_file_name_output_file,self.number_random_trees))

            # Calculate bipartition values based on starting_tree.
            self.raxml_cline_BIPARTIONS = RaxmlCommandline(self.raxml_PTHREADS_AVX_exe_filepath ,starting_tree = self.tree_file_path, model= "PROTGAMMAJTT", algorithm = "b",
                threads = 4, bipartition_filename = random_trees_file_path , working_dir = self.pymod.alignments_dirpath,
                name =  "%s_consensus_BOOT%s" % (self.new_tree_file_name_output_file, self.number_random_trees))

            self.execute_subprocess(str(self.raxml_cline_BIPARTIONS), progressbar = False)

            # Rename RAxML consensus tree output in order to be found when visualizing the tree from the 'Trees' menu.
            consensus_tree_file_path = os.path.join(self.pymod.alignments_dirpath,"%s_consensus_BOOT%s" % (self.new_tree_file_name_output_file, self.number_random_trees))

            os.rename(os.path.join(self.pymod.alignments_dirpath,"RAxML_bipartitionsBranchLabels.%s_consensus_BOOT%s" % (self.new_tree_file_name_output_file,self.number_random_trees)),
                    consensus_tree_file_path)

            # Open consensus tree (generated by RAxML) and get confidence values (in square brackets).
            with open(consensus_tree_file_path,"r") as f:
                values = f.readlines()
                for v in values:
                    bipartition_pattern_values = re.findall(r"\[([0-9_]+)\]", v)
            self.bipartition_values = bipartition_pattern_values


            self.get_bipartition_values()

            # 'Show Tree' signal.
            self.showTree.emit()
            # 'Stop Thread' signal.
            self.finished.emit()


    def get_bipartition_values(self):
        return(self.bipartition_values)


    def execute_subprocess(self,  commandline,
                           new_stdout=subprocess.PIPE, new_stderr=subprocess.PIPE,
                           new_shell=(sys.platform!="win32"),
                           verbose=True, progressbar = True):

        # "exec" causes cmd to inherit the shell process, instead of having the shell launch a child process.
        self.subp = subprocess.Popen("exec " + commandline, stdout=new_stdout, stderr=new_stderr, shell=new_shell)

        if progressbar:
            # Update ProgressBar
            x = -2
            while True:
                # Print stdout process line by line.
                lines = self.subp.stdout.readline()
                print(lines)
                if not lines:
                    break
                # Progressbar signal outputs only when stdout writes bootstrap trees.
                if len(lines) > 100 and len(lines) < 160:
                    x += 1
                    i = int(x)
                    time.sleep(0.15)
                    self.intReady.emit(i)

                else:
                    continue


        out_std, err_std = self.subp.communicate()
        returncode = self.subp.returncode

        if verbose:
            print("- Stdout:", out_std)

        if returncode != 0:
            if verbose:
                print("- Code:", returncode, ", Stderr:", err_std)
            raise Exception("Subprocess returned non-zero return code: %s (%s)" % (returncode, err_std))
        else:
            os.system(commandline)


    def get_subp(self):
        '''
        Return RAxML subprocess
        '''
        return self.subp


class PyMod_form_item(QtWidgets.QWidget):
    pass

class Tree_building_window_qt(PyMod_protocol_window_qt, PyMod_form_item):

    def build_protocol_middle_frame(self):

        # Add some options.
        self.algorithm_rds = PyMod_radioselect_qt(label_text="Clustering Algorithm",
                                                  buttons=list(sorted(tree_building_alg_dict.keys())))

        self.algorithm_rds.setvalue("Neighbor Joining")
        self.middle_formlayout.add_widget_to_align(self.algorithm_rds)

        self.calculator_rds = PyMod_radioselect_qt(label_text="Matrix Calculator",
                                                            buttons=("Identity","Blosum62"))
        self.calculator_rds.setvalue("Identity")

        self.algorithm_rds.get_button_at(0).clicked.connect(lambda a=None: self.on_click_show(self.calculator_rds))
        self.algorithm_rds.get_button_at(1).clicked.connect(lambda a=None: self.on_click_hide(self.calculator_rds))
        self.algorithm_rds.get_button_at(2).clicked.connect(lambda a=None: self.on_click_show(self.calculator_rds))

        self.middle_formlayout.add_widget_to_align(self.calculator_rds)
        self.middle_formlayout.set_input_widgets_width("auto", padding=10)

        # Advanced options for visualization.
        self.show_advanced_button()
        self.visualization_rds = PyMod_radioselect_qt(label_text="Visualization mode",
                                                  buttons=list(sorted(visualization_dict.keys())))
        self.visualization_rds.setvalue("Basic")

        self.middle_formlayout.add_widget_to_align(self.visualization_rds, advanced_option=True)
        self.middle_formlayout.set_input_widgets_width("auto", padding=10)


        self.random_trees_rds = PyMod_radioselect_qt(label_text="Number of random trees",
                                                            buttons=list(random_trees_dict.keys()))
        self.random_trees_rds.setvalue("100")
        self.middle_formlayout.add_widget_to_align(self.random_trees_rds, advanced_option=True)
        self.middle_formlayout.set_input_widgets_width("auto", padding=10)


         # 'Random Trees' Advanced Menu visible only when Bootstrap Analysis is selected.
        self.visualization_rds.get_button_at(0).clicked.connect(lambda a=None: self.on_click_hide(self.random_trees_rds))
        self.visualization_rds.get_button_at(1).clicked.connect(lambda a=None: self.on_click_hide(self.random_trees_rds))
        self.visualization_rds.get_button_at(2).clicked.connect(lambda a=None: self.on_click_show(self.random_trees_rds))
        self.visualization_rds.get_button_at(3).clicked.connect(lambda a=None: self.on_click_hide(self.random_trees_rds))
        self.visualization_rds.get_button_at(4).clicked.connect(lambda a=None: self.on_click_hide(self.random_trees_rds))
        self.visualization_rds.get_button_at(5).clicked.connect(lambda a=None: self.on_click_hide(self.random_trees_rds))


    def on_click_hide(self, buttons):
        PyMod_radioselect_qt.hide_widgets(buttons)

    def on_click_show(self, buttons):
        PyMod_radioselect_qt.show_widgets(buttons)


class Tree_visualization(Evolutionary_analysis_protocol):

    def launch_from_gui(self):
        """
        It will check if a software to build a tree is available on the user's machine.
        """
        self.tree_visualization_software = None
        can_show_tree = False
        if self.check_tree_visualization_module():
            self.tree_visualization_software = "ete3"
            can_show_tree = True

        if can_show_tree:
            self.tree_visualization_window()
        else:
            title = "Tree Visualization Error"
            message = "To render the tree via the ETE-toolkit you need to install the package."
            self.pymod.main_window.show_error_message(title, message)

    def check_tree_visualization_module(self):
        try:
            import ete3
            return True
        except ImportError:
            return False

    def tree_visualization_window(self):

        """
        Builds a window with options to show a tree out of an alignment.
        """

        self.tree_visualization_window = Tree_visualization_qt(self.pymod.main_window,
            protocol=self,
            title="Options for Tree Visualization",
            upper_frame_title="Here you can modify options for Tree Visualization",
            submit_command=self.show_plot_window_from_list)
        self.tree_visualization_window.show()

    def show_plot_window_from_list(self):

        visualization = self.get_visualization_mode()

        alignment_file_name = "alignment_tmp"
        self.alignment_file_path = os.path.join(self.pymod.alignments_dirpath, alignment_file_name + '.phylip')

        if visualization == "bp":
            self.pymod.show_tree(self.input_cluster_element)

        elif visualization == "aln":
            tree = PhyloTree(self.input_cluster_element, format = 1)

            ts = TreeStyle()
            try:
                with open(self.alignment_file_path,'r') as f:
                    aln = f.read()
                tree.link_to_alignment(aln)
            except FileNotFoundError:
                title = "Alignment File Not Found"
                message = "Do you want to open the alignment file to properly visualize the tree?"
                answer = askyesno_qt(title, message)
                if answer:
                    aln = askopenfile_qt("Open The Aligment file",
                                         name_filter= "*.fasta *.phylip",
                                         parent=self.pymod.get_qt_parent())
                    tree.link_to_alignment(aln)
                else: pass
            tree.show(tree_style=ts)


        elif visualization == "mut_single":
            tree = PhyloTree(self.input_cluster_element, format = 1)
            # If User upload Newick Tree without alignment FASTA file.
            alignment_missing = True
            while alignment_missing:
                try:
                    with open(self.alignment_file_path,'r') as f:
                        aln = f.read()
                    tree_params = ColumnMutation()
                    t, ts = tree_params.get_mutation_event(tree, aln, True)
                    alignment_missing = False

                    t.show(tree_style=ts)

                except FileNotFoundError:
                    title = "Alignment File Not Found"
                    message = "Do you want to open the alignment file to properly visualize the tree?"
                    answer = askyesno_qt(title, message)
                    if answer:
                        aln = askopenfile_qt("Open The Alignment file",
                                             name_filter= "*.fasta *.phylip",
                                             parent=self.pymod.get_qt_parent())
                        
                        self.alignment_file_path = os.path.join(self.pymod.alignments_dirpath, os.path.basename(aln))
                        self.edit_FASTA_file(aln, self.alignment_file_path)

                    else:
                        alignment_missing = False
                        pass


        elif visualization == "mut_all":
            tree = PhyloTree(self.input_cluster_element, format = 1)
            # If User upload Newick Tree without alignment FASTA file.
            alignment_missing = True
            while alignment_missing:
                try:
                    with open(self.alignment_file_path,'r') as f:
                        aln = f.read()
                    tree_params = ColumnMutation()
                    t, ts = tree_params.get_mutation_event(tree, aln, False)
                    alignment_missing = False
                    t.show(tree_style=ts)

                except FileNotFoundError:
                    title = "Alignment File Not Found"
                    message = "Do you want to open the alignment file to properly visualize the tree?"
                    answer = askyesno_qt(title, message)
                    if answer:
                        aln = askopenfile_qt("Open The Alignment file",
                                             name_filter= "*.fasta *.phylip",
                                             parent=self.pymod.get_qt_parent())

                        self.alignment_file_path = os.path.join(self.pymod.alignments_dirpath, os.path.basename(aln))
                        self.edit_FASTA_file(aln, self.alignment_file_path)

                    else:
                        alignment_missing = False
                        pass

        if visualization == "evo":
            tree = PhyloTree(self.input_cluster_element, format = 1)
            try:
                ts = TreeStyle()
                # Get evolutionary events for each internal node.
                events = tree.get_descendant_evol_events()
                i = 0
                for n in tree.traverse():
                    if not n.is_leaf():
                        ev = events[i]
                        if ev.etype == "S":
                            # Add node face.
                            n.add_face(TextFace("S",fgcolor = "blue", penwidth = 8), column = i, position = "branch-top")
                        elif ev.etype == "D":
                            # Add node face.
                            n.add_face(TextFace("D", fgcolor = "red", penwidth = 8), column = i, position = "branch-top")
                        i += 1

                ts.mode = "c"
                ts.show_leaf_name = True
                tree.show(tree_style=ts)
            except TypeError:
                title = "Evolutionary Events"
                message = "The Tree is not rooted."
                self.pymod.main_window.show_error_message(title, message)
                pass


        if visualization == "bootstrap":
            tree = PhyloTree(self.input_cluster_element, format = 1)

            # Find consensus_tree file/files.
            file_list = glob.glob(os.path.join(self.pymod.alignments_dirpath,"%s_consensus_*" % self.input_cluster_element))

            # Get Alignment_id.
            aln_id = os.path.basename(self.input_cluster_element)

            if len(file_list) == 1:
                self.consensus_tree_file_path = file_list[0]
                self.show_bootstrap_tree(tree)
            # Bootstrap Analysis run with different number of random trees.
            elif len(file_list) > 1:
                self.consensus_tree_file_path = askopenfile_qt("Open an Bootstrap Tree file",
                                               initialdir = self.pymod.alignments_dirpath,
                                               name_filter=("%s_consensus_BOOT*" % aln_id),
                                               parent=self.pymod.get_qt_parent())
                self.show_bootstrap_tree(tree)

            elif len(file_list) == 0:
                title = "Bootstrap File Not Found"
                message = "To visualize the consensus tree, first run the Bootstrap Analysis via the 'Alignments'-->'Build Tree From Alignment'-->'Advanced Options' menu."
                self.pymod.main_window.show_error_message(title, message)
                pass

    def show_bootstrap_tree (self,tree):
        # UPGMA and Parsimony need to be unrooted.
        unrooted = True
        while unrooted:
            try:
            # Open consensus tree (generated by RAxML) and get confidence values (in square brackets).
                with open(self.consensus_tree_file_path,"r") as f:
                    values = f.readlines()
                    for v in values:
                        bipartition_pattern_values = re.findall(r"\[([0-9_]+)\]", v)
                bipartition_values = bipartition_pattern_values
                # Add bootstrap values/weights to internal nodes.
                i = 0
                for n in tree.traverse():
                    if not n.is_leaf() and not n.is_root():
                        n.add_features(weight=int(bipartition_values[i]))
                        i += 1

                unrooted = False
                ts = TreeStyle()
                ts.layout_fn = bubble_ly
                ts.mode = "c"
                ts.show_leaf_name = False
                ts.show_branch_length = True
                ts.show_branch_support = False
                tree.show(tree_style=ts)

            except IndexError:
                tree.unroot() # converts a split into multifurcation
                # Save the unrooted tree in a new file.
                tree_file_path = os.path.join(self.pymod.alignments_dirpath, "%s_unrooted_tree.nwk" % self.input_cluster_element)
                tree.write(format = 1, outfile = tree_file_path)
                tree = PhyloTree(tree_file_path, format = 1)
                continue


    def get_visualization_mode(self):
        return visualization_dict[self.tree_visualization_window.visualization_rds.getvalue()]

    def edit_FASTA_file(self, input_file, output_file):
        '''
        Change the record id in a FASTA file using BioPython.
        '''
        with open(input_file) as original, open(output_file, 'w') as corrected:
            records = SeqIO.parse(input_file, 'fasta')
            print(records)
            # Duplicate names found errors.
            bad_chars = ['_', 'c', 'h', 'a', 'i', 'n'] #"_chain_"
            for record in records:
                if len(record.id) > 10:
                    if "chain" in record.id:
                        for i in bad_chars :
                            record.id = record.id.replace(i, '')
                    record.id = record.id[0:10]
                    record.description = record.id[0:10]
                SeqIO.write(record, corrected, 'fasta')

class Tree_visualization_qt(PyMod_protocol_window_qt):

    def build_protocol_middle_frame(self):

        self.visualization_rds = PyMod_radioselect_qt(label_text="Visualization mode",
                                                  buttons=list(sorted(visualization_dict.keys())))
        self.visualization_rds.setvalue("Basic")
        self.middle_formlayout.add_widget_to_align(self.visualization_rds)

        self.middle_formlayout.set_input_widgets_width("auto", padding=10)
